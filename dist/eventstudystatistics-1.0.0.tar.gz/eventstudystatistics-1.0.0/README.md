<div align="center">

# Event Study Statistics
<img src="files/logo.png" alt="icon" width="260"/>



### This repository implements the adjusted BMP / standardized cross-sectional test and the GRANK / generalized rank t test.

## Installation

```
    pip install eventstudystatistics
```

## Usage

Find an example how to use the statistics in the main.py